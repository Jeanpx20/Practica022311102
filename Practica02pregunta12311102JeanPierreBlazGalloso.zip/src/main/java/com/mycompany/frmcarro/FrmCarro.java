/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.frmcarro;

/**
 *
 * @author jean Pierre
 */
public class FrmCarro {

    public static void main(String[] args) {
        Principal princ = new Principal();
        princ.setVisible(true);
        princ.setLocationRelativeTo(null);
        
    }
}
